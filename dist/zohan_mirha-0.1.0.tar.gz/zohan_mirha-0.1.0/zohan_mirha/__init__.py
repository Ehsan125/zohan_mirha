def ehsan():
    return "Hello, Ehsan!"
